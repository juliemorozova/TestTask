﻿namespace ShapesOperations.Shapes;

public class Circle(double radius) : Shape
{
    public override double CalculateArea() => CanCalculateArea
        ? Math.PI * Math.Pow(radius, 2)
        : throw new Exception("Incorrect value of the sides");

    private bool CanCalculateArea => radius >= 0;
}