namespace ShapesOperations;

public abstract class Shape
{
    public abstract double CalculateArea();
}