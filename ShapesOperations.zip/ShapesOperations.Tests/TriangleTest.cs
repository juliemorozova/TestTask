using System.Collections.Generic;
using NUnit.Framework;
using ShapesOperations.Shapes;

namespace ShapesOperations.Tests;

[TestFixture]
[TestOf(typeof(Triangle))]
public class TriangleTest
{
    [TestCaseSource(nameof(_correctSidesAndExpectedArea))]
    public void CalculateArea_WhenCorrectValuesOfSides_ActualAreaAreEqualExpectedArea(SidesAndExpectedArea sidesAndExpectedArea)
    {
        var triangle = new Triangle(sidesAndExpectedArea.FirstSide, sidesAndExpectedArea.SecondSide,
            sidesAndExpectedArea.ThirdSide);
        var areaWasCalculated = triangle.TryCalculateArea(out var area);
        Assert.Multiple(() =>
            {
                Assert.That(areaWasCalculated);
                Assert.That(area.Equals(sidesAndExpectedArea.ExpectedArea));
            }
        );
    }

    [TestCaseSource(nameof(_incorrectSidesAndExpectedArea))]
    public void CalculateArea_WhenIncorrectValuesOfSides_AreaWasNotCalculated(SidesAndExpectedArea sidesAndExpectedArea)
    {
        var triangle = new Triangle(sidesAndExpectedArea.FirstSide, sidesAndExpectedArea.SecondSide,
            sidesAndExpectedArea.ThirdSide);
        var areaWasCalculated = triangle.TryCalculateArea(out var area);
        Assert.Multiple(() =>
            {
                Assert.That(!areaWasCalculated);
                Assert.That(area.Equals(sidesAndExpectedArea.ExpectedArea));
            }
        );
    }

    private static List<SidesAndExpectedArea> _correctSidesAndExpectedArea =
    [
        new SidesAndExpectedArea(4, 4, 6, 7.937253933193772),
        new SidesAndExpectedArea(3, 4, 5, 6),
    ];

    private static List<SidesAndExpectedArea> _incorrectSidesAndExpectedArea =
    [
        new SidesAndExpectedArea(1, 2, 3, 0),
        new SidesAndExpectedArea(-3, 4, 5, 0),
    ];
    
}

public class SidesAndExpectedArea(double firstSide, double secondSide, double thirdSide, double expectedArea)
{
    public double FirstSide { get; } = firstSide;
    public double SecondSide { get; } = secondSide;
    public double ThirdSide { get; } = thirdSide;
    
    public double ExpectedArea { get; } = expectedArea;
}