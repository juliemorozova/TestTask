namespace ShapesOperations;

public abstract class Shape
{
    public abstract bool TryCalculateArea(out double area);
}