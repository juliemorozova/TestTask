using System;
using System.Collections.Generic;
using NUnit.Framework;
using ShapesOperations.Shapes;

namespace ShapesOperations.Tests;

[TestFixture]
[TestOf(typeof(Circle))]
public class CircleTest
{
    [TestCaseSource(nameof(_radiusAndExpectedArea))]
    public void CalculateArea(RadiusAndExpectedArea radiusAndExpectedArea)
    {
        var circle = new Circle(radiusAndExpectedArea.Radius);
        var actualArea = circle.CalculateArea();
        Assert.That(actualArea.Equals(radiusAndExpectedArea.ExpectedArea));
    }

    [TestCase(-2)]
    public void CalculateArea_WhenIncorrectRadius_ThrowException(double radius)
    {
        var circle = new Circle(radius);
        Assert.Throws<Exception>(() => circle.CalculateArea());
    }

    private static List<RadiusAndExpectedArea> _radiusAndExpectedArea =
    [
        new RadiusAndExpectedArea(5, Math.PI * 25),
        new RadiusAndExpectedArea(0, 0),
    ];
}

public class RadiusAndExpectedArea(double radius, double expectedArea)
{
    public double Radius { get; } = radius;
    public double ExpectedArea { get; } = expectedArea;
}