namespace ShapesOperations.Shapes;

public class Triangle(double firstSide, double secondSide, double thirdSide) : Shape
{
    private IEnumerable<double> Sides => [firstSide, secondSide, thirdSide];
    private double[] MinSides => Sides.Except(new[] { Sides.Max() }).ToArray();

    private bool CanCalculateArea => firstSide > 0 && secondSide > 0 && thirdSide > 0 &&
                                     firstSide + secondSide > thirdSide &&
                                     firstSide + thirdSide > secondSide &&
                                     secondSide + thirdSide > firstSide;
    
    public override bool TryCalculateArea(out double area)
    {
        if (CanCalculateArea)
        {
            area = IsRightTriangle()
                ? MinSides[0] * MinSides[1] / 2
                : AreaByHeronsTheorem();
            return true;
        }

        area = 0;
        return false;
    }
    
    private bool IsRightTriangle()
    {
        var maxSide = Sides.Max();
        var sumOfLegsSquare = MinSides.Sum(l => Math.Pow(l, 2));
        var hypotenusesSquare = Math.Pow(maxSide, 2);
        return hypotenusesSquare.Equals(sumOfLegsSquare);
    }

    private double AreaByHeronsTheorem()
    {
        var halfPerimeter = Sides.Sum()/2;
        var area = Math.Sqrt(halfPerimeter * (halfPerimeter - firstSide) * (halfPerimeter - secondSide) *
                             (halfPerimeter - thirdSide));
        return area;
    }
}