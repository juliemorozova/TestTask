using System;
using System.Collections.Generic;
using NUnit.Framework;
using ShapesOperations.Shapes;

namespace ShapesOperations.Tests;

[TestFixture]
[TestOf(typeof(Circle))]
public class CircleTest
{
    [TestCaseSource(nameof(_correctRadiusAndExpectedArea))]
    public void CalculateArea_WhenCorrectRadius_ActualAreaAreEqualExpectedArea(RadiusAndExpectedArea radiusAndExpectedArea)
    {
        var circle = new Circle(radiusAndExpectedArea.Radius);
        var areaWasCalculated = circle.TryCalculateArea(out var area);
        Assert.Multiple(() =>
            {
                Assert.That(areaWasCalculated);
                Assert.That(area.Equals(radiusAndExpectedArea.ExpectedArea));
            }
        );
    }
    
    [TestCaseSource(nameof(_incorrectRadiusAndExpectedArea))]
    public void CalculateArea_WhenInCorrectRadius_AreaWasNotCalculated(RadiusAndExpectedArea radiusAndExpectedArea)
    {
        var circle = new Circle(radiusAndExpectedArea.Radius);
        var areaWasCalculated = circle.TryCalculateArea(out var area);
        Assert.Multiple(() =>
            {
                Assert.That(!areaWasCalculated);
                Assert.That(area.Equals(radiusAndExpectedArea.ExpectedArea));
            }
        );
    }

    private static List<RadiusAndExpectedArea> _correctRadiusAndExpectedArea =
    [
        new RadiusAndExpectedArea(5, Math.PI * 25),
        new RadiusAndExpectedArea(0, 0),
    ];
    
    private static List<RadiusAndExpectedArea> _incorrectRadiusAndExpectedArea =
    [
        new RadiusAndExpectedArea(-2, 0),
    ];
}

public class RadiusAndExpectedArea(double radius, double expectedArea)
{
    public double Radius { get; } = radius;
    public double ExpectedArea { get; } = expectedArea;
}