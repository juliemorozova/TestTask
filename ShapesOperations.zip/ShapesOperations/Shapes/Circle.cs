﻿namespace ShapesOperations.Shapes;

public class Circle(double radius) : Shape
{
    private bool CanCalculateArea => radius >= 0;
    public override bool TryCalculateArea(out double area)
    {
        if (CanCalculateArea)
        {
            area = Math.PI * Math.Pow(radius, 2);
            return true;
        }

        area = 0;
        return false;
    }
}